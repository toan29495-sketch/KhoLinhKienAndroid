# Step208 review — Cloud backup verification trust model

Date: 2026-11-04
Baseline: Step207 source archive.

## Work performed
- Traced the official Android backup flow from `SupabaseWeeklyBackupUploader` and the deployed Step187 SQL source in `supabase/migrations`.
- Confirmed the official app uploads to the private owner folder, performs authenticated readback, checks exact size and SHA-256, and calls `complete_inventory_backup` only after successful readback.
- Confirmed the RPC independently checks active caller, owner-scoped metadata row, registered digest equality, Storage object ownership/existence and Storage metadata size. It does not independently hash the object bytes.
- Confirmed the schema records `verification_method='CLIENT_DOWNLOAD_SHA256'`; therefore the technical distinction is represented in metadata even though the generic `VERIFIED` status can be misunderstood.
- Reviewed impact on restore: the Android restore path separately downloads and checks exact size, SHA-256, ZIP structure, manifest owner and payload before applying inventory.
- Documented options and recommendation in `BACKUP_VERIFICATION_TRUST_MODEL.md`.

## Decision boundary
Recommendation is to retain the current official-client readback plus mandatory restore-time verification, while clarifying the UI semantics. A server-side Edge verifier is a separate architectural change requiring streaming-hash design, measured 256 MiB/concurrency resource tests, backend migration and explicit approval. No implementation or deployment was made.

## Verification limits / safety
Static source review only. No hostile custom client, real Storage upload/download, large-object test, Edge resource test or restore runtime test was performed. No Supabase schema, data, Storage object, Auth user, Edge Function, grant, policy or bucket setting changed. No Gradle, APK build/install, device test or GitHub push.


## Completion audit follow-up (2026-11-04)
- Backup Cloud UI now describes `VERIFIED` as client-reported readback verification and explicitly states that the server does not independently hash the object bytes. Restore-time SHA-256/ZIP/owner checks remain mandatory.
- Android validation workflow now requires `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` repository secrets and writes ephemeral `local.properties` on the runner. YAML parse passed; the workflow has not been pushed or run for this source.
- Step139 remote migration history rechecked: all nine versions confirmed. `admin-users` live Edge Function is ACTIVE v6.
- Step190–208 regression suite: 18/18 scripts, 304/304 assertions PASS; Step114/127/141/142 regressions also pass after correcting stale verifier assumptions.
- GitHub CI has a successful earlier build on 2026-11-02 commit `21f3c878`; it is not Step208. No current-source build or device test is claimed.
