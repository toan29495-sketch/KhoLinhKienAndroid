# Bảng xử lý tồn đọng hợp nhất — mốc Step208

Ngày chốt: 04/11/2026  
Nguồn chuẩn: `KhoLinhKienAndroid-step208-backup-trust-model-20261104.zip`  
SHA-256: `fa8e6893bb946ab7cc544b1c25da48c6fcaddbe880b5c8cf530d002400f68b3c`

## Nguyên tắc điều hành

- Tạm dừng tính năng mới. Chỉ sửa lỗi, kiểm chứng và hoàn thiện các luồng đã có.
- Không tạo Step lẻ cho từng chỉnh sửa tài liệu. Dùng bảng này làm sổ tồn đọng duy nhất; chỉ ghi một mốc mới khi có thay đổi mã nguồn đáng kể hoặc nhóm việc được đóng.
- Phân biệt bốn trạng thái: **có trong source**, **đối chiếu catalog/backend**, **đã build**, **đã chạy trên thiết bị**. Không nâng trạng thái nếu thiếu bằng chứng.
- Không deploy Supabase, sửa dữ liệu, Storage/Auth, migration history hoặc push GitHub nếu chưa có yêu cầu/cho phép rõ ràng.
- Mọi thao tác restore chỉ được thay thế kho của owner đang đăng nhập; Admin xem lịch sử toàn hệ thống không có nghĩa được ghi đè kho KTV khác.

## Ưu tiên và điều kiện đóng

### P0 — Build được APK từ đúng nguồn mới nhất

**Hiện trạng:** Gradle Wrapper 8.9, AGP 8.7.3, Kotlin 2.0.21 và workflow Android validation có trong ZIP Step208. Môi trường hiện tại chỉ có JDK21, không có Android SDK/sdkmanager/adb hoặc Gradle distribution cache; lần chạy wrapper trước dừng tải distribution do DNS `services.gradle.org`. Quan trọng hơn, GitHub `main` (30/10) và `work/auth-foundation` (02/11) đều chưa chứa source Step208; branch `work/auth-foundation` vẫn README JSON-only và chưa có `gradlew`. Có một CI debug build thành công ngày 02/11 trên commit `21f3c878`, nhưng artifact đó không phải source Step208. Không được dùng artifact cũ hoặc chạy workflow cũ để xác nhận bản mới. Chi tiết tại `GITHUB_CI_RECONCILIATION_20261104.md`.

**Đã chuẩn bị:** đã tạo branch riêng `work/step208-completion-build` (không sửa `main`), thêm workflow chỉ chạy khi upload `Step208-source.zip`, và thêm hướng dẫn upload. Workflow sẽ chạy bộ regression, Kotlin compile, assemble debug APK và xuất SHA-256.

**Còn cần làm:**
1. Upload file `Step208-source.zip` vào root branch `work/step208-completion-build` bằng GitHub web UI.
2. Để workflow tự chạy trên đúng archive Step208.
3. Xác nhận `compileDebugKotlin` và `assembleDebug` đều thành công.
4. Lưu artifact APK, SHA-256, commit SHA và log workflow.
5. Không coi parser Kotlin, Python verifier hoặc ZIP integrity là build APK.

**Đóng khi:** có log workflow thành công và APK artifact gắn với đúng commit. Cài/test điện thoại là gate riêng bên dưới.

### P0 — Kiểm thử ứng dụng thật trên điện thoại

**Hiện trạng:** chưa có APK Step208 được xác nhận cài đặt; chưa có kiểm thử Android runtime cho Compose, Room migration, WorkManager, camera/QR/OCR, file picker, Storage hay các luồng đồng bộ/restore.

**Cần làm theo thứ tự:**
1. Cài APK và xác minh khởi động, nâng Room DB hiện có, đăng nhập/đăng xuất, đổi mật khẩu bắt buộc.
2. Kiểm tra Admin đồng thời là owner kho cá nhân; KTV chỉ thấy kho của mình; Admin global history chỉ là quyền xem.
3. Kiểm tra tạo/sửa/xóa linh kiện, nhập/xuất/kiểm kê, QR thiết bị và lịch sử.
4. Chạy offline rồi online; xác minh Outbox, push/pull, retry, tombstone, xung đột và đổi tài khoản.
5. Kiểm thử Backup/Restore với file nhỏ và lớn, ảnh local/cloud, mất mạng, app bị kill, thiếu dung lượng; xác minh dữ liệu KTV khác không đổi.

**Đóng khi:** có biên bản test theo ca, kết quả thực tế và không còn lỗi chặn phát hành. Các ca chưa thể chạy phải được ghi rõ, không tự đánh dấu PASS.

### P0 — Backup/Restore và bảo toàn dữ liệu

**Đã có trong source:** Cloud backup có journal/worker, owner-scoped catalog/inbox, download và kiểm tra size/SHA-256; Cloud restore có xác nhận riêng, journal, staging theo chunk, commit, đọc/xác minh snapshot rồi thay Room trong transaction; có recovery và gate ngăn sync chạy đồng thời.

**Đã xác minh:** các verifier source-contract gần nhất cho Step190–208 đạt 304/304 checks (18 scripts); bốn verifier hồi quy Step114/127/141/142 cũng PASS sau khi cập nhật assertion lỗi thời. Đây không phải kiểm thử runtime.

**Còn phải xác minh:**
- Tạo backup thật, upload/download Storage, readback SHA-256 và trạng thái `VERIFIED`.
- Restore thật với dữ liệu lớn/ảnh; mất mạng ở từng phase; process death; retry commit response không rõ; dung lượng thấp.
- So sánh chính xác số parts/movements/ảnh và cursor sau restore.
- Xác nhận restore chỉ thay owner hiện tại, giữ kho owner khác nguyên vẹn.

**Ranh giới tin cậy:** `VERIFIED` hiện dùng `CLIENT_DOWNLOAD_SHA256`: app chính thức tải đọc lại và hash; RPC backend kiểm tra metadata/size/digest đã đăng ký nhưng không tự hash bytes. UI hiện ghi rõ đây là xác minh do ứng dụng báo, không phải server-side attestation. Restore client vẫn bắt buộc tự kiểm tra SHA-256 và payload. Server-side verifier không được triển khai nếu chưa có thiết kế, đo tải và quyết định riêng; không chặn kiểm thử app chính thức.

### P1 — Supabase và đồng bộ nhiều KTV

**Đã có trong source:** `SyncOutboxSender`, `SyncPullWorker`, WorkManager scheduling, idempotency operation UUID, cursor, tombstone, xử lý xung đột, Admin global feed, owner/session fencing.

**Đã đối chiếu backend:** RPC Step138, Step187, Step204/205 cùng grants/RLS liên quan đã được kiểm tra catalog. Live role simulation ngày 04/11: Admin predicates true; KTV đang buộc đổi mật khẩu nên active predicates false; KTV bị `ADMIN_REQUIRED` khi gọi audit RPC; direct SELECT vào audit/guard tables bị từ chối. Xem `SUPABASE_LIVE_CHECK_20261104.md`. Đây là SQL claim simulation, chưa phải real Android session test. Không thay đổi backend.

**Còn phải kiểm thử:**
- Hai thiết bị cùng một owner và nhiều owner khác nhau.
- Hai thiết bị đồng thời xuất/nhập cùng linh kiện; server tuần tự hóa và tồn không âm.
- Mất mạng sau khi server commit nhưng trước khi client nhận response; retry không nhân đôi movement.
- Xung đột sửa/xóa, tombstone, Admin role downgrade và token/session cũ.
- Storage photo upload/download, retry, đổi ảnh, xóa ảnh và owner isolation.

### P1 — Kiểm toán bảo mật runtime

**Đã hoàn thành:** đọc tĩnh từng định nghĩa của 20 RPC `SECURITY DEFINER` được `authenticated` gọi; phân loại 6 trigger functions và 1 event trigger; không thấy anon/PUBLIC EXECUTE trong catalog; fixed search_path. Đã mô phỏng role claim trong transaction: Admin gate được, KTV gate bị từ chối; KTV audit RPC trả `ADMIN_REQUIRED`.

**Còn thiếu:** authenticated adversarial tests, malicious payload/fault injection, concurrency tests, role downgrade/session tests, và xác minh Storage/RLS qua client thực. Chưa đánh dấu kiểm toán bảo mật đóng.

### P2 — Hòa giải lịch sử migration Step139

**Đã xác nhận lịch sử remote.** `list_migrations` và truy vấn trực tiếp `supabase_migrations.schema_migrations` ngày 04/11/2026 đều xác nhận đủ 9 version Step139, từ `20261103100431` đến `20261103101525`. Sai lệch trước đó do ảnh chụp/listing cũ không đầy đủ và đã được sửa trong `supabase/REMOTE_MIGRATION_MANIFEST.md`.

**Còn lại, không chặn phát hành:** 25 SQL file pending là tập lịch sử pha trộn; không thể khôi phục byte-for-byte nội dung SQL gốc hoặc transaction boundaries chỉ từ các file này. Giữ nguyên làm bằng chứng; không replay, không `migration repair`, không tạo migration giả.

**Đóng phần đối chiếu remote:** đủ 9/9 version được xác nhận. Phần khôi phục nguyên văn SQL gốc được ghi nhận là giới hạn provenance, không phải migration đang thiếu trên production.

### P2 — Dọn cảnh báo và tối ưu sau khi P0/P1 ổn định

- Đánh giá FK indexes thiếu trên audit actor/target IDs bằng workload thực trước khi thêm. Advisor hiện còn 2 unindexed FKs và 6 unused-index notices; không thêm/xóa index theo snapshot rỗng.
- Theo dõi RPC Admin backup status không phân trang khi dữ liệu tăng.
- Đánh giá leaked-password protection và Advisor warnings; không cấp quyền rộng hoặc xóa index chỉ để làm sạch cảnh báo.

## Những việc không làm trong giai đoạn này

- Không thêm tính năng mới hoặc thay đổi UI ngoài sửa lỗi phát hiện trong kiểm thử.
- Không triển khai Edge Function xác minh SHA-256 server-side khi chưa có thiết kế/đo tải/duyệt.
- Không chạy `supabase db push`, không replay 25 migration pending, không sửa migration history theo phỏng đoán.
- Không xóa dữ liệu test hoặc Storage objects từ xa.
- Không push source lên `main` hoặc deploy production nếu chưa có bước duyệt riêng. Branch build cô lập đã được tạo theo yêu cầu xử lý tồn đọng; chưa upload binary source ZIP.

## Bằng chứng kiểm tra tại mốc hợp nhất

- ZIP nguồn Step208 ban đầu được xác minh SHA-256: `fa8e6893bb946ab7cc544b1c25da48c6fcaddbe880b5c8cf530d002400f68b3c`; gói hoàn thiện mới sẽ có checksum riêng trong `COMPLETION_AUDIT_20261104.md`.
- `python -m compileall -q tools`: PASS.
- Verifier Step190–208: 18 scripts, 304/304 assertions PASS.
- Các kiểm tra trên là source-contract checks; không thay thế Kotlin/Gradle build hoặc Android/Supabase runtime tests.


## Cập nhật trạng thái sau kiểm tra trực tiếp (04/11/2026)
- Step139 remote migration history: **9/9 confirmed** qua `list_migrations` và SQL ledger; phần “thiếu migration history” được đóng. Original SQL byte-for-byte provenance vẫn là giới hạn tài liệu, không phải gap trên production.
- `admin-users`: ACTIVE v6; live handler kiểm tra bearer token, active Admin, forced-password completion và `app_admins` link.
- Backup UI đã đổi nhãn để giải thích `VERIFIED` là xác minh readback do ứng dụng báo; máy chủ không tự hash bytes. Restore vẫn tự tải và xác minh độc lập.
- Verifier Step190–208: 18/18 scripts, 304/304 assertions PASS; bốn verifier hồi quy Step114/127/141/142 cũng PASS. Các verifier cũ Step114, Step127, Step141, Step142, Step200, Step204/205, Step207 cũng được cập nhật theo contract hiện hành và PASS.
- CI remote có một debug build thành công ngày 02/11 trên commit cũ `21f3c878`; không phải Step208. Build APK Step208 và test Android thật vẫn chưa thể hoàn tất: GitHub branches gốc chưa có source Step208; đã chuẩn bị branch upload riêng nhưng binary ZIP chưa được upload. Môi trường hiện tại không có Android SDK/Gradle distribution/ADB. Không push nhầm source cũ, không tuyên bố build/test thành công.
