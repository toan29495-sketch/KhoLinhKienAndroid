# Supabase live verification — 2026-11-04

Project: `ihhxxxqojelbxisreqns`  
Scope: read-only catalog/advisor inspection and transaction-scoped role simulation. No persistent SQL, schema, migration, Auth, Storage, Edge Function, or business-data mutation.

## Migration history

- `list_migrations` returned 23 tracked migrations: 7 Step138, 9 Step139, 3 Step187, 2 Step204, and 2 Step205.
- Direct read-only query of `supabase_migrations.schema_migrations` confirmed Step139 count 9, first `20261103100431`, last `20261103101525`.
- The Step206/207 statement that all nine Step139 versions were missing was wrong; it came from an incomplete/stale listing. It is superseded.
- The 25 SQL files in `migrations_pending_reconciliation` are a mixed historical source set and do not reproduce the original Step139 SQL bodies byte-for-byte. Keep them out of active migrations; do not replay or use blanket `db push`.

## Edge Function

- `admin-users` is ACTIVE version 6, `verify_jwt=false` because the handler performs manual bearer validation.
- Live source validates `auth.getUser`, active Admin profile, completed forced-password change, and `app_admins` membership.
- Live bundle fingerprint reported by Supabase: `6fd84795d68c6f71a827764757edda112a56146d1f2113ae21e0200a368b94ca`.
- No deployment performed during this check.

## Role simulation (transaction-scoped; no persistent changes)

- Existing Admin profile: `is_active_profile=true`, `is_app_admin=true`, `is_active_admin_profile=true`.
- Existing KTV profile: `must_change_password=true`; all three predicates returned `false`, as required until the temporary password is changed.
- Admin call to `list_admin_audit_events(10)` succeeded and returned zero rows.
- KTV call to the same RPC was rejected with `ADMIN_REQUIRED`.
- `authenticated` has no direct SELECT privilege on `admin_audit_events` or `password_reset_guard`.
- This used a simulated JWT subject claim inside a rollback transaction, not a real Android login/session. It is not an end-to-end Auth test.

## Current Advisor snapshot

Security:
- 6 RLS-enabled tables have no policies: internal audit/guard and restore/sync staging/event tables. Direct client grants are absent; guarded RPCs are the intended access path.
- 20 authenticated-callable `SECURITY DEFINER` functions are flagged. The catalog review found no `PUBLIC` EXECUTE grants and fixed `search_path` on all 27 public `SECURITY DEFINER` functions.
- Leaked-password protection remains disabled. Do not enable blindly while KTV onboarding uses temporary password `000000`; redesign onboarding first.

Performance:
- 2 unindexed FKs on `admin_audit_events` (`actor_id`, `target_user_id`).
- 6 unused indexes in the current low-activity/empty workload snapshot. Do not remove indexes based only on this observation.

No Advisor finding was changed or suppressed.
